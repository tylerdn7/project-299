import os
from subprocess import call
from flask import Flask, request
from werkzeug.utils import redirect

app = Flask(__name__)

@app.route("/")
def index():
    if request.method == 'GET':
        print("Image Super Resolution is processing")
        call(["python", "isupres.py"])
        return redirect("http://localhost/isr/result.html", code=200)
#ind()
if __name__==("__main__"):
    app.run()

#os.system('python replica.py')



